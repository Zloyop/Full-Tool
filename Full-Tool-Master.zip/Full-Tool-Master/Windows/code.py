import pyAesCrypt
import os
from win10toast import ToastNotifier

def show_notify(title, text):
    toast = ToastNotifier()
    toast.show_toast(title, text, duration=1)

def encrypter(_mode, _file):

    password = input("Enter password: ")
    buffer = 512 * 1024
    ext = _file.split(".")
    if(int(_mode) == 1):
        pyAesCrypt.encryptFile(_file, ext[0].lower() + '.full', password, buffer)
        
    elif(int(_mode) == 2):
        _type = input("Enter type: ")
        pyAesCrypt.decryptFile(_file, ext[0].lower() + "." + _type, password, buffer)
        
    os.remove(_file)



def rucrypter(_mode, _file):

    password = input('Введи пароль: ')
    buffer = 512 * 1024
    ext = _file.split(".")
    if(int(_mode) == 1):
        pyAesCrypt.encryptFile(_file, ext[0].lower() + '.full', password, buffer)
        
    elif(int(_mode) == 2):
        _type = input("Введи тип файла: ")
        pyAesCrypt.decryptFile(_file, ext[0].lower() + "." + _type, password, buffer)
        
    os.remove(_file)

print("Choose language / Выбери язык:")
print("0 - En")
print("1 - Ru")
lang = int(input("Enter lang: "))


while True:

    if lang == 0:
        print("""
___________     __   __    ___________            __   
\_   _____/_ __|  | |  |   \__    ___/___   ____ |  |  
 |    __)|  |  \  | |  |     |    | /  _ \ /  _ \|  |  
 |     \ |  |  /  |_|  |__   |    |(  <_> |  <_> )  |__
 \___  / |____/|____/____/   |____| \____/ \____/|____/
     \/                                                
               Version    1.0     
 =============================================
            Made by Zloy op               
            Updates: github.com/Zloyop         
 =============================================
        [1] Crypt   [2] Decrypt  [3] More info
        """)
        mode = input("Enter mode: ")
        filename = input("Enter file name: ")
        encrypter(mode, filename)
        show_notify("Fool Tool", "Done!")
    elif lang == 1:
        print("""
___________     __   __    ___________            __   
\_   _____/_ __|  | |  |   \__    ___/___   ____ |  |  
 |    __)|  |  \  | |  |     |    | /  _ \ /  _ \|  |   
 |     \ |  |  /  |_|  |__   |    |(  <_> |  <_> )  |__
 \___  / |____/|____/____/   |____| \____/ \____/|____/
     \/                                                
               Версия    1.0     
 =============================================
            Сделал Zloy op               
            Обновления: github.com/Zloyop         
 =============================================
[1] Зашифровать  [2] Разшифровать [3] Больше информации
        """)
        mode = input("Введи режим: ")
        filename = input("Введи имя файла: ")
        rucrypter(mode, filename)
        show_notify("Fool Tool", "Готово!")
